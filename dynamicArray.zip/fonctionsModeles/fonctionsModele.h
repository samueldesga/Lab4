#pragma once
using namespace std;
template <typename T>
T TrouverMax(const T _tabType[], const int& nbElement);

template <typename T>
T CalculerSomme(const T _tabType[], const int& nbElement);

template <typename T>
unsigned int CompterElement(const T _valeur, const T _tabType[], const int& nbElement);

#include "fonctionsModele.hpp"